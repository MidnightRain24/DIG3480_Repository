﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController: MonoBehaviour {

	public AudioClip BGMusic;
	public AudioClip Cat;
	public AudioClip Dog; 
	public AudioClip Victory;
	public AudioSource audioSource;
	public float speed;
	public Text score;
	public Text lives;
	public Text win;
	private int scoreValue = 0;
	private Rigidbody2D rd2d;
	private int lifeValue = 3;
	private bool facingRight = true;
	private bool stun = false;
	Animator anim;

	void Start() {
		rd2d = GetComponent<Rigidbody2D>();
		anim = GetComponent<Animator>();
		score.text = "Score: " + scoreValue.ToString();
		lives.text = "Lives: " + lifeValue.ToString();
		win.text = "";
		anim.SetInteger("State", 0);
		BackgroundMusic();
	}
	
	void Update() {
		if (Input.GetKey("escape")) {
			Application.Quit();
		}
		if (Input.GetKey("r")){
			SceneManager.LoadScene (SceneManager.GetActiveScene().name);
		}
	}

	void FixedUpdate() {
		if (lifeValue != 0) {
			if (stun == false){
				float hozMovement = Input.GetAxis("Horizontal");
				float verMovement = Input.GetAxis("Vertical");
				rd2d.AddForce (new Vector2 (hozMovement * speed, verMovement));
				if (facingRight == false && hozMovement > 0) {
					Flip();
				} else if (facingRight == true && hozMovement < 0) {
					Flip();
				}
				if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.A)) {
					if (this.anim.GetInteger("State") != 5) {
						anim.SetInteger("State", 1);
					}
				}
				if (Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.A)) {
					if (this.anim.GetInteger("State") != 5) {
						anim.SetInteger("State", 0);
					}
				}
			}
		}
	}

	private void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.CompareTag("Coin")){
			other.gameObject.SetActive (false);
			audioSource.PlayOneShot(Cat);
			scoreValue += 1;
			score.text = "Score: " + scoreValue.ToString();
			if (scoreValue == 4 && lifeValue != 0){
				lifeValue = 3;
				lives.text = "Lives: " + lifeValue.ToString();
				transform.position = new Vector2(83.6f, 1.4f); 
			}
			if (scoreValue == 8 && lifeValue != 0) {
				win.text = "Congratulations, you win! Press 'R' to restart, or 'Esc' to quit. Game by Gavin Crossland.";
				WinMusic();
			}
		}
		if (other.gameObject.CompareTag("Enemy")){
			other.gameObject.SetActive (false);
			audioSource.PlayOneShot(Dog);
			Hurt();
			lifeValue -= 1;
			lives.text = "Lives: " + lifeValue.ToString();
			if (lifeValue == 0) {
				anim.SetInteger("State", 6);
				win.color = Color.red;
				win.text = "You lost! Press 'R' to restart, or 'Esc' to quit.";
			}
		}
	}

	private void Hurt() {
		anim.SetInteger("State", 5);
		Invoke("Recover", 0.9f);
		stun = true;
	}

	private void Recover() {
		anim.SetInteger("State", 0);
		stun = false;
	}

	private void OnCollisionStay2D(Collision2D collision) {
		if (collision.collider.tag == "Ground") {
			if (Input.GetKey(KeyCode.W) && lifeValue != 0) {
				rd2d.AddForce (new Vector2 (0, 13), ForceMode2D.Impulse);
				anim.SetInteger("State", 3);
			}
		}
	}

	private void OnCollisionEnter2D(Collision2D collision){
		if (collision.collider.tag == "Ground"){
			if (this.anim.GetInteger("State") == 3 && lifeValue != 0) {
				anim.SetInteger("State", 0);
			}
		}
	}

	private void Flip() {
     facingRight = !facingRight;
     Vector2 Scaler = transform.localScale;
     Scaler.x = Scaler.x * -1;
     transform.localScale = Scaler;
   }

   private void BackgroundMusic() {
		audioSource.loop = true;
   	   	audioSource.clip = BGMusic;
		audioSource.Play();
   }

   private void WinMusic() {
   	   audioSource.loop = false;
	   audioSource.clip = Victory;
	   audioSource.Play();
   }
}