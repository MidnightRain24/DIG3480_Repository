﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {
	public float speed;
	public Text countText;
	public Text winText;
	public Text lifeText;
	private Rigidbody2D rb2d;
	private int count;
	private int life;

	void Start() {
		rb2d = GetComponent<Rigidbody2D> ();
		count = 0;
		life = 3;
		winText.text = "";
		SetCountText();
		SetLifeText();
	}

	void FixedUpdate() {
		if (life != 0) {
			float moveHorizontal = Input.GetAxis ("Horizontal");
			float moveVertical = Input.GetAxis ("Vertical");
			Vector2 movement = new Vector2 (moveHorizontal, moveVertical);
			rb2d.AddForce(movement * speed);
		}
		if (Input.GetKey("escape")){
			Application.Quit();
		}
		if (Input.GetKey("r")){
			SceneManager.LoadScene (SceneManager.GetActiveScene().name);
		}
	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.CompareTag("Pickup")){
			other.gameObject.SetActive (false);
			count = count + 1;
			SetCountText();
		}
		if (other.gameObject.CompareTag("Deathup")) {
			other.gameObject.SetActive (false);
			life = life - 1;
			SetLifeText();
		}
		if (count == 12) {
			transform.position = new Vector2(100.0f, 83.8f); 
		}
	}

	void SetLifeText() {
		lifeText.text = "Lives: " + life.ToString ();
		if (life == 0) {
			winText.color = Color.red;
			winText.text = "Your ship has been destroyed! Press 'R' to restart, or 'Esc' to quit.";
		}
	}

	void SetCountText() {
		countText.text = "Count: " + count.ToString ();
		if (count >= 20 && life != 0) {
			winText.text = "Congratulations, you win! Press 'R' to restart, or 'Esc' to quit.";
		}
	}
}