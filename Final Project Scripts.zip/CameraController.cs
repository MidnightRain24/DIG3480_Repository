﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController: MonoBehaviour {

	public AudioClip BGMusic;
	public AudioClip Victory;
	public AudioClip Loss;
	public AudioSource audioSource;
	public GameObject target;
	public PlayerController player;
	private int score;
	private	int life;

	void Start() {
		BackgroundMusic();
		score = player.points;
		life = player.health;
	}
	
	void FixedUpdate() {
		this.transform.position = new Vector3(target.transform.position.x, target.transform.position.y, this.transform.position.z);
	}

	private void BackgroundMusic() {
		audioSource.loop = true;
   	   	audioSource.clip = BGMusic;
		audioSource.Play();
	}
   
   public void WinMusic() {
		audioSource.loop = false;
		audioSource.Stop();
		audioSource.PlayOneShot(Victory);
   }

   public void LoseMusic() {
		audioSource.loop = false;
		audioSource.Stop();
		audioSource.PlayOneShot(Loss);
   }
}