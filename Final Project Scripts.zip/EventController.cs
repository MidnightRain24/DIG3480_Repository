﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EventController : MonoBehaviour {

	public AudioClip Coin;
	public AudioClip Cat;
	public AudioSource aS;
	public static bool audioEcho;
	public PlayerController player;
	private float timeRemaining;

    void Start() {
		audioEcho = true;
	}

    void Update() {
		if (Input.GetKey("escape")) {
			Application.Quit();
		}
		if (Input.GetKey("r")){
			SceneManager.LoadScene (SceneManager.GetActiveScene().name);
		}
		timeRemaining = player.clock;
	}

	public void CoinCollection() {
		aS.PlayOneShot(Coin, 0.5f);
	}

	public void DamageTaken() {
		if (audioEcho) {
			aS.PlayOneShot(Cat, 0.3f);
			audioEcho = false;
			if (timeRemaining > 0) {
				Invoke("Delay", Cat.length);
			}
		}
	}
	
	private void Delay() {
		audioEcho = true;
	}
}