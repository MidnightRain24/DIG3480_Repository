﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController: MonoBehaviour {

	public AudioClip walk;
	public AudioClip jump;
	public AudioSource audioSource;
	public Text score;
	public Text lives;
	public Text win;
	public Text time;
	public GameObject background1;
	public GameObject background2;
	public EventController eventHandler;
	public CameraController cameramusic;
	public float speed;
	private Rigidbody2D rd2d;
	private bool facingRight = true;
	private float hozMovement;
	private float verMovement;
	Animator anim;
	public int points;
	public int health;
	public bool stun;
	public float clock;
	private bool immunity;


	void Start() {
		stun = false;
		points = 0;
		health = 3;
		clock = 30;
		rd2d = GetComponent<Rigidbody2D>();
		anim = GetComponent<Animator>();
		anim.SetInteger("State", 0);
		score.text = "Coins: " + points.ToString();
		lives.text = "Lives: " + health.ToString();
		win.text = "";
		time.text = "";
		immunity = false;
	}

	void Update() {
		if (clock < 30) {
			time.color = Color.green;
		}
		if (clock < 20) {
			time.color = Color.yellow;
		}
		if (clock < 10) {
			time.color = Color.red;
		}
		if ((clock < 0) && (clock > -0.1) && immunity == false && health != 0) {
			health = 0;
			lives.text = "Lives: " + health.ToString();
			eventHandler.DamageTaken();
			Death();
			cameramusic.LoseMusic();
		}
		if ((clock > 0) && immunity == false && health != 0) {
			clock -=Time.deltaTime;
			float sec = Mathf.Round(clock);
			time.text = sec.ToString() + " seconds.";
		} else if ((clock < 0) && immunity == false) {
			time.color = Color.red;
			time.text = "0 seconds!";
		} else if (health == 0 && clock > 0) {
			time.color = Color.red;
			time.text = "0 seconds!";
		} else if (immunity == true) {
			time.color = Color.green;
			float sec = Mathf.Round(clock);
			time.text = sec.ToString() + " seconds!";
		}
	}	

	void FixedUpdate() {
		hozMovement = Input.GetAxis("Horizontal");
		verMovement = Input.GetAxis("Vertical");
		if  (health != 0 && clock > 0) {
			if (stun == false){
				rd2d.AddForce (new Vector2 (hozMovement * speed, verMovement));
				if (facingRight == false && hozMovement > 0) {
					Flip();
				} else if (facingRight == true && hozMovement < 0) {
					Flip();
				}
				if (hozMovement != 0) {
					if (this.anim.GetInteger("State") != 5) {
						anim.SetInteger("State", 1);
					}
				}
				if (hozMovement == 0) {
					if (this.anim.GetInteger("State") != 5) {
						anim.SetInteger("State", 0);
					}
					if (verMovement == 0){
						audioSource.Stop();
					}
				}
				if (verMovement > 0){
					anim.SetInteger("State", 3);
				}
			}
		}
	}

	private void OnTriggerEnter2D(Collider2D other) {
		if (other.gameObject.CompareTag("Coin")) {
			eventHandler.CoinCollection();
			points += 1;
			score.text = "Coins: " + points.ToString();
			if (points == 4 && health != 0 && clock > 0) {
				health = 3;
				lives.text = "Lives: " + health.ToString();
				transform.position = new Vector2(83.6f, 1.4f);
			}
			if (points == 8 && health != 0 && clock > 0) {
				win.text = "Congratulations, you win!\nPress 'R' to restart, or 'Esc' to quit.\nGame by Gavin Crossland.";
				cameramusic.WinMusic();
				immunity = true;
			}
			other.gameObject.SetActive (false);
		}
		if (other.gameObject.CompareTag("Enemy")){
			Hurt();
			health -= 1;
			lives.text = "Lives: " + health.ToString();
			eventHandler.DamageTaken();
			if (health == 0) {
				Death();
				cameramusic.LoseMusic();
			}
			other.gameObject.SetActive (false);
		}
		if (other.gameObject.CompareTag("Spikes") && health != 0 && clock > 0) {
			health = 0;
			lives.text = "Lives: " + health.ToString();
			eventHandler.DamageTaken();
			Death();
			cameramusic.LoseMusic();
		}
		if (other.gameObject.CompareTag("Background 1")){
			background1.SetActive(true);
			background2.SetActive(false);
		}
		if (other.gameObject.CompareTag("Background 2")){
			background1.SetActive(false);
			background2.SetActive(true);
		}
	}

	private void OnCollisionStay2D(Collision2D collision) {
		if (collision.collider.tag == "Ground") {
			if (Input.GetKey(KeyCode.W) && health != 0 && clock > 0) {
				rd2d.AddForce (new Vector2 (0, 13), ForceMode2D.Impulse);
			}
			if ((Input.GetKeyDown(KeyCode.A)||Input.GetKeyDown(KeyCode.D)) && health != 0 && clock > 0) {
				audioSource.PlayOneShot(walk, 0.8f);
			}
		}
	}

	private void OnCollisionExit2D(Collision2D collision) {
		if (collision.collider.tag == "Ground"){
			if (audioSource.clip = walk) {
				audioSource.Stop();
			}
			if (verMovement != 0) {
				audioSource.PlayOneShot(jump);
			}
		}
	}

	private void OnCollisionEnter2D(Collision2D collision){
		if (collision.collider.tag == "Ground"){
			if (this.anim.GetInteger("State") == 3 && health != 0 && clock > 0) {
				anim.SetInteger("State", 0);
			}
			if ((hozMovement != 0) && health != 0 && clock > 0) {
				audioSource.PlayOneShot(walk, 0.8f);
			}
		}
	}

	public void Death() {
		stun = true;
		anim.SetInteger("State", 6);
		win.color = Color.red;
		win.text = "You lost!\nPress 'R' to restart, or 'Esc' to quit.";
	}

	private void Flip() {
     facingRight = !facingRight;
     Vector2 Scaler = transform.localScale;
     Scaler.x = Scaler.x * -1;
     transform.localScale = Scaler;
   }

   	public void Hurt() {
		anim.SetInteger("State", 5);
		Invoke("Recover", 0.9f);
		stun = true;
	}

	public void Recover() {
		anim.SetInteger("State", 0);
		stun = false;
	}
}